document.addEventListener("DOMContentLoaded", () => {
  const yearSpan = document.getElementById("year");
  const form = document.getElementById("contactForm");
  const formMessage = document.getElementById("formMessage");

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear().toString();
  }

  if (form && formMessage) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const message = document.getElementById("message").value.trim();

      if (!name || !email || !message) {
        formMessage.textContent = "Por favor completa todos los campos.";
        formMessage.style.color = "#f97373";
        return;
      }

      formMessage.textContent = "Mensaje enviado. Gracias por escribir, responderé lo antes posible.";
      formMessage.style.color = "#22c55e";
      form.reset();

      setTimeout(() => {
        formMessage.textContent = "";
      }, 5000);
    });
  }
});
